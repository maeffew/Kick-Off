<?php
namespace Gantry\Theme;

use Gantry\Framework\Theme;

class G5_Helium extends Theme {}
